# Summer XSLT Demo project

A simple project to demonstrate how to develop with Spring Boot and XSLT 3.0 using Green Summer.

See the blog entry, [XML/XSLT 3.0 development with Spring Boot, Saxon and Summer](https://www.greeneyed.org/post/xml-xslt-3-0-development-with-spring-boot-saxon-and-summer/), for reference.
