package org.clp.xslt.demo.model;

public interface Constant {

    String QUEUE_NAME = "ptp";

    String TOPIC_NAME = "pubsub";
    
    // for consumer
    String QUEUE_CONTAINER = "ptpContainer";

    //String TOPIC_CONTAINER = "pubsubContainer";    

    String RESPONSE_SUCCESS = "success";
}